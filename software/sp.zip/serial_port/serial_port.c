#define green_leds (char *) 0x00001030
#define switches (volatile char *) 0x00001050

#define RS232_Control (*(volatile unsigned char *)(0x84000200))
#define RS232_Status  (*(volatile unsigned char *)(0x84000200))
#define RS232_TxData  (*(volatile unsigned char *)(0x84000202))
#define RS232_RxData  (*(volatile unsigned char *)(0x84000202))
#define RS232_Baud    (*(volatile unsigned char *)(0x84000204))

#include <stdlib.h>
#include <stdio.h>
#include "io.h"
#include "altera_up_avalon_character_lcd.h"

/*** functions ***/
void Init_RS232(void);
int putcharRS232(int c);
int getcharRS232(void);
int RS232TestForReceivedData(void);
alt_up_character_lcd_dev * initLCD();

/*** MAIN ***/
int main(void) {
	/* LCD */
	alt_up_character_lcd_dev * char_lcd_dev = initLCD();
	alt_up_character_lcd_string(char_lcd_dev, "^.^>Exercise 1.3");
	alt_up_character_lcd_set_cursor_pos(char_lcd_dev, 0, 1);
	alt_up_character_lcd_string(char_lcd_dev, "     Serial Port");

	/* Serial */
	Init_RS232();
	while (1){
	int got = putcharRS232( 48 );
	printf("REC: %d\n", got);
	}
	return 0;
}

/*** function definitions ***/

// initLCD - enables the use of the Altera LCD screen
alt_up_character_lcd_dev * initLCD()
{
	alt_up_character_lcd_dev * char_lcd_dev;
	char_lcd_dev = alt_up_character_lcd_open_dev("/dev/character_lcd_0");

	if(char_lcd_dev == NULL) {
		printf ("Error: could not open character LCD device\n");
	} else {
		printf ("< LCD Initialized >\n");
	}

	/* Initialize the character display */
	alt_up_character_lcd_init(char_lcd_dev);

	return char_lcd_dev;
}

// set up the 6850 Control Register
void Init_RS232(void)
{
	// divide by 16 clock,
	// set RTS low, use 8 bits of data, no parity, 1 stop bit,
	// transmitter interrupt disabled
	RS232_Control = 0x15;

	// program baud rate generator to use 115k baud
	RS232_Baud = 0x01;
}

// poll Tx bit in 6850 status register. LOCKING
int putcharRS232(int c)
{
	while ( (RS232_Status & 0x02) != 0x02 );

	RS232_TxData = c & 0xFF;
	return c;
}

// poll Rx bit in 6850 status register
int getcharRS232( void )
{
	while ( !RS232TestForReceivedData() );

	int c = RS232_RxData;
	printf("GOT: %d\n", c);
	return c;
}

// the following function polls the 6850 to determine if any character
// has been received. It doesn't wait for one, or read it, it simply tests
// to see if one is available to read
int RS232TestForReceivedData( void )
{
	// Test Rx bit in 6850 serial comms chip status register
	// if RX bit is set, return TRUE, otherwise return FALSE
	if (RS232_RxData == 1) {
		return 1;
	} else {
		return 0;
	}
}

